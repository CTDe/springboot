package com.aokace.controller;

import java.util.Map;

public class ReturnObj {
private String statu;
private String msg;
private Map<String, String> result;
public static ReturnObj buildSuccess() {
	ReturnObj returnObj=new ReturnObj();
	returnObj.setStatu("200");
	returnObj.setMsg("success");
	return returnObj;
}

public static ReturnObj buildFault() {
	ReturnObj returnObj=new ReturnObj();
	returnObj.setStatu("400");
	returnObj.setMsg("fault");
	return returnObj;
}

public String getStatu() {
	return statu;
}
public void setStatu(String statu) {
	this.statu = statu;
}
public String getMsg() {
	return msg;
}
public void setMsg(String msg) {
	this.msg = msg;
}
public Map<String, String> getResult() {
	return result;
}
public void setResult(Map<String, String> result) {
	this.result = result;
}

}
