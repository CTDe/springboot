package com.aokace.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.aokace.common.Result;
import com.aokace.entity.Survey;
import com.aokace.service.SurveyService;

@Controller
public class SurveyController {
	private SurveyService surveyService;
	
	//@PostMapping("/save")
	//public boolean save(@RequestBody Survey survey) {
		//return surveyService.save(survey);
	//}
	
	@PostMapping("/save")
	public Result save(@RequestBody Survey survey) {
		return surveyService.save(survey)?Result.suc():Result.fail();
	}
}
