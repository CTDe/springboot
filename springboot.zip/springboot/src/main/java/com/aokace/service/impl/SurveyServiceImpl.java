package com.aokace.service.impl;

import org.springframework.stereotype.Service;

import com.aokace.dao.SurveyMapper;
import com.aokace.entity.Survey;
import com.aokace.service.SurveyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

@Service
public class SurveyServiceImpl extends ServiceImpl<SurveyMapper,Survey> implements SurveyService{

}
