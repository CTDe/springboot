package com.aokace.service;

import com.aokace.entity.Survey;
import com.baomidou.mybatisplus.extension.service.IService;

public interface SurveyService extends IService<Survey>{

}
