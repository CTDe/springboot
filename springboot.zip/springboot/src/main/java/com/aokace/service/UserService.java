package com.aokace.service;

import com.aokace.entity.User;

public interface UserService {
Boolean verifyUser(User user);
}
