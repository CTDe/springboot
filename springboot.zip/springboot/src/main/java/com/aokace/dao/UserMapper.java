package com.aokace.dao;

import org.apache.ibatis.annotations.Mapper;

import com.aokace.entity.User;

@Mapper
public interface UserMapper {
	User getUser(String username);
}
