package com.aokace.dao;

import org.apache.ibatis.annotations.Mapper;

import com.aokace.entity.Survey;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
@Mapper
public interface SurveyMapper extends BaseMapper<Survey>{

}
