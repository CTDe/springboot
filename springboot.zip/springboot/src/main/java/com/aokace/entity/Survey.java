package com.aokace.entity;

import com.baomidou.mybatisplus.annotation.TableField;

public class Survey {
	private int id;
	private String username;
	private String mail;
	private String opinion;
	private String endoscope;
	private String serves;
	@TableField("isvalid")
	private String isValid;

	public Survey() {
		super();
	}

	public Survey(int id, String username, String mail, String opinion, String endoscope, String serves,
			String isValid) {
		super();
		this.id = id;
		this.username = username;
		this.mail = mail;
		this.opinion = opinion;
		this.endoscope = endoscope;
		this.serves = serves;
		this.isValid = isValid;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getOpinion() {
		return opinion;
	}

	public void setOpinion(String opinion) {
		this.opinion = opinion;
	}

	public String getEndoscope() {
		return endoscope;
	}

	public void setEndoscope(String endoscope) {
		this.endoscope = endoscope;
	}

	public String getServes() {
		return serves;
	}

	public void setServes(String serves) {
		this.serves = serves;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

}
